import hashlib
from util_ConfigManager import get_firestore_client
# Get a Firestore client
db = get_firestore_client()