import functions_framework


@functions_framework.http
def my_http_function(request):
    # Your code here

    # Return an HTTP response
    return "OK"
